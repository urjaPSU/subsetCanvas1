package StudentManagement;

import CourseManagement.CourseInstance;
import UserAuthentication.Person;

import java.util.ArrayList;

public class Student extends Person {
    private String CollegeID;
    private ArrayList <CourseInstance> coursesRegistered;
    private String AdmitSemID;

    public Student(String login, String pwd){
        super(login, pwd);
    }
    public Student(String login, String pwd, String college, String admitsem){
        super(login, pwd);
        this.CollegeID = college;
        this.AdmitSemID = admitsem;
        }

    public ArrayList<CourseInstance> getCoursesRegistered() {
        return coursesRegistered;
    }
}
