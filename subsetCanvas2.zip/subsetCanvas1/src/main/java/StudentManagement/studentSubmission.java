package StudentManagement;

public class studentSubmission {
    private String StudentID;
    private String SubmissionID;
    private String ModuleID;
    private String submitFile;
    private double pointsReveived;

    public void upload(){}
}
