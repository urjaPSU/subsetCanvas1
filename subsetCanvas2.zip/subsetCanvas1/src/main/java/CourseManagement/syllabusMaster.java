package CourseManagement;

import CourseManagement.Course;
import CourseManagement.Module;

import java.util.ArrayList;

public class syllabusMaster {
    private String SyllabusID;
    private Course course;
    ArrayList<Module> syllabModules;

    public syllabusMaster(String syllabid, Course cou){}
    public void viewSyllabus(){}
    public void createSyllabus(){}
    public void updateSyllabus(){}
}
