package FacultyManagement;

public class FacultyInterface {
    public FacultyInterface(){
        System.out.println("Welcome to Faculty Interface");
        System.out.println("Assign Courses to Instructors");
        }
}
