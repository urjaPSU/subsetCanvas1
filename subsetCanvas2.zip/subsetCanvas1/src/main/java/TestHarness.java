import UserAuthentication.LoginController;

public class TestHarness {
    public static void main(String[] args){
        LoginController lc = new LoginController();
    }
}
